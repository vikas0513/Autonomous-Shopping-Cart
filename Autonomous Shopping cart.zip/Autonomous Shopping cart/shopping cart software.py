from random import randint

class AutonomousShoppingCart:
    def _init_(self):
        self.cart = []
        self.total_price = 0

    def add_item(self, item):
        """Add a specified item to the cart."""
        self.cart.append(item)
        self.total_price += item['price']
        print(f"Added: {item['name']} - ${item['price']:.2f}")
        print(f"Total Price: ${self.total_price:.2f}\n")

    def remove_item(self, item_name):
        """Remove a specified item from the cart."""
        for item in self.cart:
            if item['name'].lower() == item_name.lower():
                self.cart.remove(item)
                self.total_price -= item['price']
                print(f"Removed: {item['name']} - ${item['price']:.2f}")
                print(f"Total Price: ${self.total_price:.2f}\n")
                return
        print(f"Item '{item_name}' not found in cart.\n")

    def list_cart(self):
        """List all items currently in the cart."""
        if not self.cart:
            print("Your cart is empty.\n")
            return
        print("Cart Contents:")
        for i, item in enumerate(self.cart, start=1):
            print(f"{i}. {item['name']} - ${item['price']:.2f}")
        print(f"Total Price: ${self.total_price:.2f}\n")

    def checkout(self):
        """Simulate the checkout process."""
        if not self.cart:
            print("Your cart is empty. Nothing to checkout.\n")
            return
        print("Checking out...")
        print(f"Final Total: ${self.total_price:.2f}")
        print("Thank you for shopping with us!\n")
        self.cart.clear()
        self.total_price = 0

# Simulated store with available items
def generate_store():
    item_names = ["Apple", "Banana", "Milk", "Bread", "Eggs", "Cheese", "Cereal", "Juice"]
    store = [{"name": name, "price": round(randint(100, 1000) / 100, 2)} for name in item_names]
    return store

def select_item(store):
    """Prompt the user to select an item from the store."""
    print("Available Store Items:")
    for i, item in enumerate(store, start=1):
        print(f"{i}. {item['name']} - ${item['price']:.2f}")
    print("")
    
    while True:
        try:
            choice = int(input("Enter the item number to add to the cart: "))
            if 1 <= choice <= len(store):
                return store[choice - 1]
            else:
                print("Invalid choice. Please select a valid item number.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def main():
    print("Welcome to the Autonomous Shopping Cart Simulation!")
    store = generate_store()
    cart = AutonomousShoppingCart()

    while True:
        print("\nOptions:")
        print("1. Add an item to the cart")
        print("2. Remove an item from the cart")
        print("3. View cart contents")
        print("4. Checkout")
        print("5. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            item = select_item(store)
            cart.add_item(item)
        elif choice == "2":
            item_name = input("Enter the name of the item to remove: ").strip()
            cart.remove_item(item_name)
        elif choice == "3":
            cart.list_cart()
        elif choice == "4":
            cart.checkout()
        elif choice == "5":
            print("Exiting the simulation. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.\n")

if _name_ == "_main_":
    main()
